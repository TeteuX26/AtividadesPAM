console.log ('manifest/ carregou');

if ("serviceworker" in navigator){
    
}

let soma = (a, b) => a + b;

let s = soma (1,2);
console.log(s);