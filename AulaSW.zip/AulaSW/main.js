if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('sw.js')
      .then(ServiceWorker => {
        console.log(ServiceWorker);
          })
      .catch(
        error =>{
        console.log(error);
            });

} else {
    console.log("Seu navegador não suporta SrviceWorker");
}
     
